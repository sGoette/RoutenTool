# Visualize GPX Tracks on SwissTopo Maps
## Installation
Clone this git repo to your computer
Open a console and prompt it the the "RoutenTool" folder. 
Run the command `npm install`
If nodeJS and/or npmjs isn't installed yet, install them first. On Linux run the command `sudo apt install nodejs npm`
Prompt the console to the parent folder of "RoutenTool" and run the command `node RoutenTool`
The console logs the URL and Port over which you can access the Visualizer. 

## Load GPX Tracks
On the first run the program creates a folder called "data" inside the "RoutenTool" folder. 
Load your .GPX files inside this folder. 
Reload the side in your browser
Now you should see the Tracks embedes in the map. 
